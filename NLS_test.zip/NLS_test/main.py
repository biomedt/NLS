from tkinter import *
from math import *
from tkinter.messagebox import *
from inspect import *
import pandas as pd
from tkinter.filedialog import *
import csv as cs


root = Tk()
root.title("NLScore Calculator")
root.geometry('800x400')
root["bg"] = "white"
root.attributes("-alpha", 0.9)
path = getfile(currentframe())
abspath = path.replace('main.py', 'proba.csv')
abspath2 = path.replace('main.py', 'huayi.png')
abspath3 = path.replace('main.py', 'jida.png')
abspath4 = path.replace('main.py', 'result.csv')
prob = pd.read_csv(abspath, header=0)
threshold = prob.iloc[:, 0]
F01 = prob.iloc[:, 1]
F2 = prob.iloc[:, 2]
F34 = prob.iloc[:, 3]
photo1 = PhotoImage(file=abspath2)
photo2 = PhotoImage(file=abspath3)
PLabel1 = Label(root, image=photo1, width=65, height=50)
PLabel2 = Label(root, image=photo2, width=65, height=50)
PLabel1.place(x=700, y=320)
PLabel2.place(x=640, y=320)

main_label = Label(root, text='NLScore', font=('Arial', 10, 'bold'), bg='white', justify='center', width=10)
main_label.place(x=150, y=275)
main_label2 = Label(root, text='Risk', font=('Arial', 10, 'bold'), bg='white', justify='center', width=10)
main_label2.place(x=250, y=275)
main_label8 = Label(root, text='F0&F1 Prob', font=('Arial', 10, 'bold'), bg='white', justify='center', width=10)
main_label8.place(x=350, y=275)
main_label9 = Label(root, text='F2 Prob', font=('Arial', 10, 'bold'), bg='white', justify='center', width=10)
main_label9.place(x=450, y=275)
main_label10 = Label(root, text='F3&F4 Prob', font=('Arial', 10, 'bold'), bg='white', justify='center', width=10)
main_label10.place(x=550, y=275)

main_label3 = Label(root, text='', font=('Arial', 10), bg='black', justify='center', width=10, fg='white')
main_label4 = Label(root, text='', font=('Arial', 10), bg='black', justify='center', width=10, fg='white')
main_label5 = Label(root, text='', font=('Arial', 10), bg='black', justify='center', width=10, fg='white')
main_label6 = Label(root, text='', font=('Arial', 10), bg='black', justify='center', width=10, fg='white')
main_label7 = Label(root, text='', font=('Arial', 10), bg='black', justify='center', width=10, fg='white')

main_label3.place(x=150, y=250)
main_label4.place(x=250, y=250)
main_label5.place(x=350, y=250)
main_label6.place(x=450, y=250)
main_label7.place(x=550, y=250)

main_label9 = Label(root, text='NLS Calculator', font=('Arial', 30,'bold'), bg='white', justify='center')
main_label9.place(x=265, y=20)
main_label10 = Label(root, text='NAFLD liver stiffness score for detecting significant hepatic fibrosis', font=('Arial', 15), bg='white')
main_label10.place(x=110, y=80)

def TT(x):
    y = 1
    x.insert(0, y)


def FF(x):
    y = 0
    x.insert(0, y)

def check_bool(content):
    if (content == '0') | (content == '1') | (content == ''):
        return TRUE
    else:
        return FALSE



def P1():
    window = Tk()
    window.title("AGE≥40")
    window.geometry("500x500")
    window.config(bg="white")
    Entry1 = Entry(window, width=5)
    Entry1.place(x=100, y=50)
    Entry2 = Entry(window, width=5)
    Entry2.place(x=100, y=100)
    Entry3 = Entry(window, width=5)
    Entry3.place(x=100, y=150)
    entry_validation= window.register(check_bool)
    Entry4 = Entry(window, width=5,validate='all', vcmd=(entry_validation, '%P'))
    Entry4.place(x=100, y=200)
    Entry5 = Entry(window, width=5,validate='all', vcmd=(entry_validation, '%P'))
    Entry5.place(x=100, y=250)
    Entry6 = Entry(window, width=5)
    Entry6.place(x=100, y=300)
    Entry7 = Entry(window, width=5)
    Entry7.place(x=100, y=350)


    label1 = Label(window, text="GGT", font=('Arial', 10), bg='white')
    label1.place(x=50, y=50)
    label2 = Label(window, text="AST", font=('Arial', 10), bg='white')
    label2.place(x=50, y=100)
    label3 = Label(window, text="ALB", font=('Arial', 10), bg='white')
    label3.place(x=50, y=150)
    label4 = Label(window, text="Race", font=('Arial', 10), bg='white')
    label4.place(x=50, y=200)
    label5 = Label(window, text='Diabetes', font=('Arial', 10), bg='white')
    label5.place(x=40, y=250)
    label6 = Label(window, text="PLT", font=('Arial', 10), bg='white')
    label6.place(x=50, y=300)
    label7 = Label(window, text="GLB", font=('Arial', 10), bg='white')
    label7.place(x=50, y=350)

    label9 = Label(window, text="U/L(max(GGT)=50)", font=('Arial', 10), bg='white')
    label9.place(x=150, y=50)
    label10 = Label(window, text="U/L", font=('Arial', 10), bg='white')
    label10.place(x=150, y=100)
    label11 = Label(window, text="g/L", font=('Arial', 10), bg='white')
    label11.place(x=150, y=150)
    label12 = Label(window, text="10^9/L", font=('Arial', 10), bg='white')
    label12.place(x=150, y=300)
    label13 = Label(window, text="g/L", font=('Arial', 10), bg='white')
    label13.place(x=150, y=350)

    Button1 = Button(window, text="Asian", width=10, command=lambda:TT(Entry4))
    Button1.place(x=150, y=200)
    Button2 = Button(window, text="non-Asian", width=10, command=lambda:FF(Entry4))
    Button2.place(x=250, y=200)
    Button3 = Button(window, text="Diabetes", width=10, command=lambda:TT(Entry5))
    Button3.place(x=150, y=250)
    Button4 = Button(window, text="non-Diabetes", width=10, command=lambda:FF(Entry5))
    Button4.place(x=250, y=250)

    def NLS():
        try:
            GGT = float(Entry1.get())
            AST = float(Entry2.get())
            ALB = float(Entry3.get())
            Race = float(Entry4.get())
            DIQ = float(Entry5.get())
            PLT = float(Entry6.get())
            GLB = float(Entry7.get())
            if GGT>=50:
                GGT=50
            NLScore = 0.19605 * DIQ + 0.06489 * log2(GGT) + 0.15142 * log2(AST) - 0.10907 * log2(PLT) + 0.18804 * log2(GLB/ALB) - 0.09647 * Race + 2.45140
            NLScore = round(NLScore, 3)
            if NLScore >= 2.725:
                Risk='High Risk'
            elif NLScore < 2.573:
                Risk='Low Risk'
            else:
                Risk='Median Risk'
            sub = list(abs(NLScore-threshold))
            min_index = sub.index(min(sub))
            F01_prob=round(F01[min_index], 3)
            F2_prob=round(F2[min_index], 3)
            F34_prob=round(F34[min_index], 3)
        except:
            NLScore = 'NA'
            Risk = 'NA'
            F01_prob='NA'
            F2_prob='NA'
            F34_prob='NA'

        main_label3 = Label(root, text=NLScore, font=('Arial', 10, 'bold'), bg='black', justify='center' , width=10, fg='white')
        main_label4 = Label(root, text=Risk, font=('Arial', 10, 'bold'), bg='black', justify='center' , width=10, fg='white')
        main_label5 = Label(root, text=F01_prob, font=('Arial', 10, 'bold'), bg='black', justify='center' , width=10, fg='white')
        main_label6 = Label(root, text=F2_prob, font=('Arial', 10, 'bold'), bg='black', justify='center' , width=10, fg='white')
        main_label7 = Label(root, text=F34_prob, font=('Arial', 10, 'bold'), bg='black', justify='center' , width=10, fg='white')

        main_label3.place(x=150, y=250)
        main_label4.place(x=250, y=250)
        main_label5.place(x=350, y=250)
        main_label6.place(x=450, y=250)
        main_label7.place(x=550, y=250)

        Entry1.delete(0, END)
        Entry2.delete(0, END)
        Entry3.delete(0, END)
        Entry4.delete(0, END)
        Entry5.delete(0, END)
        Entry6.delete(0, END)
        Entry7.delete(0, END)
        window.destroy()
    Button5 = Button(window, text="Calculate", width=10, command=NLS)
    Button5.place(x=150, y=400)

    def clear():
        Entry1.delete(0, END)
        Entry2.delete(0, END)
        Entry3.delete(0, END)
        Entry4.delete(0, END)
        Entry5.delete(0, END)
        Entry6.delete(0, END)
        Entry7.delete(0, END)

    Button_cle = Button(window, text="Clear", width=10, command=clear)
    Button_cle.place(x=250, y=400)

def P2():
    window = Tk()
    window.title("AGE<40")
    window.geometry("500x500")
    window.config(bg="white")
    Entry1 = Entry(window, width=5)
    Entry1.place(x=100, y=50)
    Entry2 = Entry(window, width=5)
    Entry2.place(x=100, y=100)
    Entry3 = Entry(window, width=5)
    Entry3.place(x=100, y=150)
    entry_validation= window.register(check_bool)
    Entry4 = Entry(window, width=5,validate='all', vcmd=(entry_validation, '%P'))
    Entry4.place(x=100, y=200)
    Entry5 = Entry(window, width=5,validate='all', vcmd=(entry_validation, '%P'))
    Entry5.place(x=100, y=250)
    Entry6 = Entry(window, width=5)
    Entry6.place(x=100, y=300)
    Entry7 = Entry(window, width=5)
    Entry7.place(x=100, y=350)


    label1 = Label(window, text="GGT", font=('Arial', 10), bg='white')
    label1.place(x=50, y=50)
    label2 = Label(window, text="AST", font=('Arial', 10), bg='white')
    label2.place(x=50, y=100)
    label3 = Label(window, text="ALB", font=('Arial', 10), bg='white')
    label3.place(x=50, y=150)
    label4 = Label(window, text="Race", font=('Arial', 10), bg='white')
    label4.place(x=50, y=200)
    label5 = Label(window, text='Diabetes', font=('Arial', 10), bg='white')
    label5.place(x=40, y=250)
    label6 = Label(window, text="UA", font=('Arial', 10), bg='white')
    label6.place(x=50, y=300)
    label7 = Label(window, text="HDL", font=('Arial', 10), bg='white')
    label7.place(x=50, y=350)

    label9 = Label(window, text="U/L", font=('Arial', 10), bg='white')
    label9.place(x=150, y=50)
    label10 = Label(window, text="U/L", font=('Arial', 10), bg='white')
    label10.place(x=150, y=100)
    label11 = Label(window, text="g/L", font=('Arial', 10), bg='white')
    label11.place(x=150, y=150)
    label12 = Label(window, text="μmol/L", font=('Arial', 10), bg='white')
    label12.place(x=150, y=300)
    label13 = Label(window, text="U/L", font=('Arial', 10), bg='white')
    label13.place(x=150, y=350)

    Button1 = Button(window, text="Asian", width=10, command=lambda:TT(Entry4))
    Button1.place(x=150, y=200)
    Button2 = Button(window, text="non-Asian", width=10, command=lambda:FF(Entry4))
    Button2.place(x=250, y=200)
    Button3 = Button(window, text="Diabetes", width=10, command=lambda:TT(Entry5))
    Button3.place(x=150, y=250)
    Button4 = Button(window, text="non-Diabetes", width=10, command=lambda:FF(Entry5))
    Button4.place(x=250, y=250)

    def NLS():
        try:
            GGT = float(Entry1.get())
            AST = float(Entry2.get())
            ALB = float(Entry3.get())
            Race = float(Entry4.get())
            DIQ = float(Entry5.get())
            UA = float(Entry6.get())
            HDL = float(Entry7.get())
            NLScore=0.14300*DIQ+0.07588*log2(GGT)+0.08266*log2(AST)+0.12087*log2(UA/HDL)-0.31596*log2(ALB)-0.15531 *Race+2.45154
            NLScore = round(NLScore, 3)
            if NLScore >= 2.725:
                Risk = 'High Risk'
            elif NLScore < 2.573:
                Risk = 'Low Risk'
            else:
                Risk = 'Median Risk'
            sub = list(abs(NLScore-threshold))
            min_index = sub.index(min(sub))
            F01_prob=round(F01[min_index], 3)
            F2_prob=round(F2[min_index], 3)
            F34_prob=round(F34[min_index], 3)
        except:
            NLScore = 'NA'
            Risk = 'NA'
            F01_prob='NA'
            F2_prob='NA'
            F34_prob='NA'
        main_label3 = Label(root, text=NLScore, font=('Arial', 10, 'bold'), bg='black', justify='center', width=10, fg='white')
        main_label4 = Label(root, text=Risk, font=('Arial', 10, 'bold'), bg='black', justify='center', width=10, fg='white')
        main_label5 = Label(root, text=F01_prob, font=('Arial', 10, 'bold'), bg='black', justify='center', width=10, fg='white')
        main_label6 = Label(root, text=F2_prob, font=('Arial', 10, 'bold'), bg='black', justify='center', width=10, fg='white')
        main_label7 = Label(root, text=F34_prob, font=('Arial', 10, 'bold'), bg='black', justify='center', width=10, fg='white')

        main_label3.place(x=150, y=250)
        main_label4.place(x=250, y=250)
        main_label5.place(x=350, y=250)
        main_label6.place(x=450, y=250)
        main_label7.place(x=550, y=250)

        Entry1.delete(0, END)
        Entry2.delete(0, END)
        Entry3.delete(0, END)
        Entry4.delete(0, END)
        Entry5.delete(0, END)
        Entry6.delete(0, END)
        Entry7.delete(0, END)
        window.destroy()

    Button5 = Button(window, text="Calculate", width=10, command=NLS)
    Button5.place(x=150, y=400)

    def clear():
        Entry1.delete(0, END)
        Entry2.delete(0, END)
        Entry3.delete(0, END)
        Entry4.delete(0, END)
        Entry5.delete(0, END)
        Entry6.delete(0, END)
        Entry7.delete(0, END)

    Button_cle = Button(window, text="Clear", width=10, command=clear)
    Button_cle.place(x=250, y=400)



def Introduction():
    showinfo('Introduction', '    End-stage hepatic fibrosis (HF) has poor therapeutic value and earlier intervention benefits to good prognosis. Hence, earlier accurate diagnosis of HF is top prority. Chronic progression, insignificant symptoms and large number of patients indicate that liver cirrhosis should have large-scale and long-term supervision, which is a bottleneck for detection required expensive equipment and invasive biopsy. Hospital will waste huge medical resources to provide long-term detection for large amount of NAFLD patients using these common detections. Hence, we construct an accurate significant HF prediction serum model called NLS to solve the intractable problem. Recently, NLS performed well in several datasets containing over 1000 biopsy samples. We aimed to extend NLS as an effective method for large-scale and long-term supervision of significant HF in NAFLD patients to all over the world.')

def Help():
    showinfo('Help', '    NLScore is the output of NLS to predict hepatic fibrosis of NAFLD patients. Risk indicates the mortality of HF in NAFLD patients. F0&F1, F2 and F3&F4 respectively showed prevalence rate of early-stage or without HF, significant HF and end-stage HF in NAFLD patients.\n    Any questions please e-mail ljzlxylzhyl@163.com or wuchutian2021@163.com')

def Close():
    root.destroy()


def Load():
    path = askopenfilename()
    if path != '':
        if '.csv' in path:
            try:
                csvfile = pd.read_csv(path, header=0)
            except:
                showerror('Error', 'Read_Error!!!')
        elif '.xlsx' in path:
            try:
                csvfile = pd.read_excel(path, header=0)
            except:
                showerror('Error', 'Read_Error!!!')
        else:
            try:
                csvfile = pd.read_xlsx(path, header=0, sep='\t')
            except:
                showerror('Error', 'Read_Error!!!')
        try:
            AGE = list(csvfile['AGE'])
            ALB = list(csvfile['ALB'])
            AST = list(csvfile['AST'])
            GGT = list(csvfile['GGT'])
            UA = list(csvfile['UA'])
            HDL = list(csvfile['HDL'])
            Race = list(csvfile['Race'])
            Diabetes = list(csvfile['Diabetes'])
            GLB = list(csvfile['GLB'])
            PLT = list(csvfile['PLT'])
            NLScore = []
            for i in range(len(AGE)):
                if AGE[i] >= 40:
                    if GGT[i] >= 50:
                        GGT[i] = 50
                    NL = 0.197 * Diabetes[i] + 0.102 * log2(GGT[i]) + 0.140 * log2(AST[i]) - 0.100 * log2(PLT[i]) + 0.164 * log2(GLB[i] / ALB[i]) - 0.113 * Race[i] + 2.256
                    NLScore.append(NL)
                elif AGE[i] < 40:
                    NL = 0.149 * Diabetes[i] + 0.082 * log2(GGT[i]) + 0.092 * log2(AST[i]) + 0.122 * log2(UA[i] / HDL[i]) - 0.295 * log2(ALB[i]) - 0.149 * Race[i] + 2.258
                    NLScore.append(NL)
            Risk=[]
            F01_prob=[]
            F2_prob=[]
            F34_prob=[]
            for i in range(len(NLScore)):
                if NLScore[i] >= 2.725:
                    Risk.append('High Risk')
                elif NLScore[i] < 2.573:
                    Risk.append('Low Risk')
                else:
                    Risk.append('Median Risk')
                sub = list(abs(NLScore[i] - threshold))
                min_index = sub.index(min(sub))
                F01_prob.append(round(F01[min_index], 3))
                F2_prob.append(round(F2[min_index], 3))
                F34_prob.append(round(F34[min_index], 3))
            output = pd.DataFrame({'AGE': AGE, 'ALB': ALB, 'GGT': GGT, 'PLT': PLT, 'AST': AST, 'Race': Race, 'Diabetes': Diabetes, 'UA': UA, 'HDL': HDL, 'GLB': GLB, 'NLScore': NLScore, 'Risk':Risk, 'F01_Prob':F01_prob, 'F2_Prob':F2_prob, 'F34_Prob':F34_prob})
            with open(abspath4, 'a', encoding='utf-8', newline='') as f:
                csv_write = cs.writer(f, dialect='excel')
                csv_write.writerow(['AGE', 'ALB', 'GGT', 'PLT', 'AST', 'Race', 'Diabetes', 'UA', 'HDL', 'GLB', 'NLScore','Risk','F01_Prob','F2_Prob','F34_Prob'])
                for line in range(len(NLScore)):
                    csv_write.writerow(output.iloc[line, :])
            showinfo('Success', 'Result file is successful constructed at the directory of main.exe')
        except:
            showerror('Error', 'Calculate_Error!!!')



menubar = Menu(root)

#fmenu = Menu(menubar)
#fmenu.add_command(label='AGE>=40', command=P1)
#fmenu.add_command(label='AGE<40', command=P2)

#menubar.add_cascade(label='Calculation', menu=fmenu)
Button_P1 = Button(root, text="AGE≥40", width=10, height=3, command=P1, bg='white', font=('Arial', '10', 'bold'))
Button_P2 = Button(root, text="AGE<40", width=10, height=3, command=P2, bg='white', font=('Arial', '10', 'bold'))
Button_P1.place(x=405, y=150)
Button_P2.place(x=305, y=150)
menubar.add_command(label='Introduction', command=Introduction)
menubar.add_command(label='Help', command=Help)
menubar.add_command(label='Batch', command=Load)
menubar.add_command(label='Close', command=Close)

root['menu'] = menubar


root.mainloop()  # 进入消息循环
